
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="text/html">
    <title><?php echo e($title); ?></title>    
</head>
<body>
    <h1>SPORTSPOT</h1>
    <p>
        <?php echo e($body); ?>

    </p>
    <a href="http://sportspot.com.co">Sportspot</a>.    

</body>
</html>
<?php /**PATH /home/fxydd484qnxs/public_html/resources/views/email_template.blade.php ENDPATH**/ ?>